# PAMAP2 Human Activity Classification — reimplementation

Student reimplementation of **Athens, Blum & Singh, "Human Activity Classification",
Stanford CS229 Fall 2018** ([report](https://cs229.stanford.edu/proj2018/report/6.pdf),
[poster](https://cs229.stanford.edu/proj2018/poster/6.pdf)). We are not the original authors.
Original code: https://github.com/aristosathens/Human_Activity_Classifier.
Dataset: PAMAP2, UCI — https://archive.ics.uci.edu/dataset/231/pamap2+physical+activity+monitoring
(Reiss & Stricker, 2012).

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q                      # all tests run on synthetic data
```
Put the raw files at `data/raw/PAMAP2_Dataset/Protocol/subject101.dat ... subject109.dat`
(or set `HAR_RAW_DIR`). `data/` is git-ignored.

## Run
```bash
python -m scripts.build_dataset                       # Person 1 — cleaned parquet + split
python -m experiments.p1.run_logreg --feature-set both
python -m experiments.p1.run_svm --stage A --feature-set both
python -m experiments.p2.run_trees --model tree --feature-set both
python -m experiments.p2.run_trees --model forest --feature-set both
python -m experiments.p2.run_trees --model adaboost --feature-set both --skip-tune
python -m experiments.p2.run_mlp --feature-set both --epochs 100
python -m experiments.compare_results
python -m har.plots --cm adaboost_reduced --curve tree_reduced:max_depth logreg_full:C:log
```

## Ownership
| Path | Owner |
|---|---|
| `har/config.py`, `har/data.py`, `har/splits.py`, `har/metrics.py`, `har/runner.py`, `har/synthetic.py`, `har/plots.py`, `scripts/`, `README.md`, `requirements.txt`, `.gitignore`, `pytest.ini` | Person 1 |
| `har/models_p1/`, `experiments/p1/`, `tests/test_data.py`, `tests/test_splits_leakage.py`, `tests/test_p1_models.py`, `tests/test_integration.py` | Person 1 |
| `har/models_p2/`, `experiments/p2/`, `experiments/compare_results.py`, `tests/test_p2_models.py` | Person 2 |
| `docs/decisions_p1.md` / `docs/decisions_p2.md` | Person 1 / Person 2 (append-only) |

Every difference from the paper is logged in `docs/decisions_p1.md` or `docs/decisions_p2.md`.
