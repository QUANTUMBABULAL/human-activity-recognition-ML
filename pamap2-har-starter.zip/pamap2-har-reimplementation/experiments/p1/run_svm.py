"""SVM experiments. OWNER: Person 1.

Stage A (must):   python -m experiments.p1.run_svm --stage A --feature-set both
Stage B (should): python -m experiments.p1.run_svm --stage B --feature-set both
Fallback:         python -m experiments.p1.run_svm --stage A --skip-tune --fit-n 20000 --test-n 50000
"""
import argparse

import pandas as pd

from har.config import RESULTS_DIR
from har.data import get_xy, load_processed
from har.models_p1 import svm
from har.runner import run_experiment, subsample
from har.splits import load_split


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="A", choices=["A", "B"])
    ap.add_argument("--feature-set", default="both", choices=["full", "reduced", "both"])
    ap.add_argument("--tune-n", type=int, default=20_000)
    ap.add_argument("--fit-n", type=int, default=50_000)
    ap.add_argument("--test-n", type=int, default=None, help="None = whole test split")
    ap.add_argument("--skip-tune", action="store_true")
    a = ap.parse_args()

    df, split = load_processed(), load_split()
    for fs in (["full", "reduced"] if a.feature_set == "both" else [a.feature_set]):
        X, y = get_xy(df, fs, subsample(split["train"], a.tune_n))
        if a.stage == "B":       # kernel comparison only, CV numbers, no test evaluation
            _, rows = svm.cv_grid(X, y, kernels=("linear", "poly", "rbf"),
                                  C_grid=[0.1, 1.0, 10.0, 100.0], max_iter=200_000)
            pd.DataFrame(rows).to_csv(RESULTS_DIR / "metrics" / f"svm_kernels_{fs}_cv.csv",
                                      index=False)
            continue
        C, cv_info = svm.PAPER[fs]["C"], {"skipped": True}
        if not a.skip_tune:
            best, rows = svm.cv_grid(X, y, kernels=("rbf",))
            C = best["C"]
            pd.DataFrame(rows).to_csv(RESULTS_DIR / "metrics" / f"svm_rbf_{fs}_cv.csv", index=False)
            cv_info = {"n_folds": 5, "tune_rows": len(y), "grid": svm.C_GRID,
                       "rule": "max mean val accuracy", "chosen_C": C}
        model = svm.build("rbf", C)
        rec = run_experiment(model_name="svm_rbf", owner="P1", model=model, df=df, split=split,
                             feature_set=fs, params={"kernel": "rbf", "C": C, "gamma": "auto"},
                             paper_test_accuracy=svm.PAPER_TEST_ACC[fs], fit_n=a.fit_n,
                             test_n=a.test_n, train_eval_n=20_000, cv_info=cv_info,
                             notes=f"fit on {a.fit_n} sampled training rows")
        print("support vectors:", int(model.named_steps["clf"].n_support_.sum()),
              "of", rec["n_train"])


if __name__ == "__main__":
    main()
