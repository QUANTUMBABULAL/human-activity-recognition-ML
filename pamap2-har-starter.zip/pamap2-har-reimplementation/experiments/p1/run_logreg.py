"""Logistic regression experiments. OWNER: Person 1.

python -m experiments.p1.run_logreg --feature-set both
python -m experiments.p1.run_logreg --feature-set reduced --skip-tune   (use paper C=0.01)
"""
import argparse

import pandas as pd

from har.config import RESULTS_DIR
from har.data import get_xy, load_processed
from har.models_p1 import logreg
from har.runner import run_experiment, subsample
from har.splits import load_split


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feature-set", default="both", choices=["full", "reduced", "both"])
    ap.add_argument("--tune-n", type=int, default=200_000, help="training rows used for CV")
    ap.add_argument("--fit-n", type=int, default=None, help="rows for final fit (None=all)")
    ap.add_argument("--skip-tune", action="store_true")
    a = ap.parse_args()

    df, split = load_processed(), load_split()
    for fs in (["full", "reduced"] if a.feature_set == "both" else [a.feature_set]):
        C, cv_info = logreg.PAPER["C"], {"skipped": True}
        if not a.skip_tune:
            X, y = get_xy(df, fs, subsample(split["train"], a.tune_n))
            C, table = logreg.tune_C(X, y)
            pd.DataFrame(table).to_csv(RESULTS_DIR / "metrics" / f"logreg_{fs}_cv.csv", index=False)
            cv_info = {"n_folds": 5, "tune_rows": len(y), "grid": logreg.C_GRID,
                       "rule": "max mean val accuracy", "chosen_C": C}
        run_experiment(model_name="logreg", owner="P1", model=logreg.build(C=C), df=df,
                       split=split, feature_set=fs, params={"C": C, "solver": "sag"},
                       paper_test_accuracy=logreg.PAPER_TEST_ACC[fs], fit_n=a.fit_n,
                       cv_info=cv_info, notes="L2 + SAG; scaler fit on training rows only")


if __name__ == "__main__":
    main()
