"""Decision tree / AdaBoost / random forest experiments. OWNER: Person 2.

python -m experiments.p2.run_trees --model tree     --feature-set both
python -m experiments.p2.run_trees --model forest   --feature-set both
python -m experiments.p2.run_trees --model adaboost --feature-set both --skip-tune
python -m experiments.p2.run_trees --model adaboost --feature-set reduced --tune-n 20000
    (grid run: saved as adaboost_<set>_grid.json and kept OUT of the main comparison;
     the main table uses the paper-setting run)
"""
import argparse

import pandas as pd

from har.config import RESULTS_DIR
from har.data import get_xy, load_processed
from har.models_p2 import trees
from har.runner import run_experiment, subsample
from har.splits import load_split

DEFAULTS = {  # rows used for CV / final fit (None = all training rows)
    "tree": {"tune_n": 200_000, "fit_n": None},
    "forest": {"tune_n": 100_000, "fit_n": None},
    "adaboost": {"tune_n": 20_000, "fit_n": 200_000},
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=list(DEFAULTS))
    ap.add_argument("--feature-set", default="both", choices=["full", "reduced", "both"])
    ap.add_argument("--tune-n", type=int, default=None)
    ap.add_argument("--fit-n", type=int, default=None)
    ap.add_argument("--all-train", action="store_true", help="final fit on ALL training rows")
    ap.add_argument("--skip-tune", action="store_true", help="use the paper's settings")
    a = ap.parse_args()
    tune_n = a.tune_n or DEFAULTS[a.model]["tune_n"]
    fit_n = None if a.all_train else (a.fit_n or DEFAULTS[a.model]["fit_n"])

    df, split = load_processed(), load_split()
    for fs in (["full", "reduced"] if a.feature_set == "both" else [a.feature_set]):
        params, cv_info = dict(trees.PAPER[a.model][fs]), {"skipped": True}
        if not a.skip_tune:
            X, y = get_xy(df, fs, subsample(split["train"], tune_n))
            if a.model == "adaboost":
                chosen, table = trees.adaboost_grid(X, y)
                params = {"max_depth": chosen["max_depth"], "n_estimators": chosen["n_estimators"]}
            else:
                est = trees.build_tree() if a.model == "tree" else trees.build_forest()
                depths = trees.TREE_DEPTHS if a.model == "tree" else trees.FOREST_DEPTHS
                d, table = trees.depth_curve(est, X, y, depths)
                params["max_depth"] = d
            pd.DataFrame(table).to_csv(RESULTS_DIR / "metrics" / f"{a.model}_{fs}_cv.csv",
                                       index=False)
            cv_info = {"n_folds": 5, "tune_rows": len(y), "rule": "one-SD rule", "chosen": params}
        build = {"tree": trees.build_tree, "forest": trees.build_forest,
                 "adaboost": trees.build_adaboost}[a.model]
        grid_run = a.model == "adaboost" and not a.skip_tune
        run_experiment(model_name=a.model, owner="P2", model=build(**params), df=df,
                       split=split, feature_set=fs, params=params,
                       paper_test_accuracy=trees.PAPER_TEST_ACC[a.model][fs],
                       fit_n=fit_n, cv_info=cv_info, notes=f"final fit rows: {fit_n or 'all'}",
                       tag="_grid" if grid_run else "",
                       protocol="random_85_15_adaboost_grid" if grid_run else "random_85_15")


if __name__ == "__main__":
    main()
