"""MLP experiments. OWNER: Person 2.

python -m experiments.p2.run_mlp --feature-set both --epochs 100
Fallback (slow laptop): --epochs 30 --fit-n 400000
"""
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from har.config import RESULTS_DIR
from har.data import load_processed
from har.models_p2.mlp import PAPER_TEST_ACC, KerasMLP
from har.runner import run_experiment
from har.splits import load_split


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feature-set", default="both", choices=["full", "reduced", "both"])
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--fit-n", type=int, default=None)
    a = ap.parse_args()

    df, split = load_processed(), load_split()
    for fs in (["full", "reduced"] if a.feature_set == "both" else [a.feature_set]):
        mlp = KerasMLP(epochs=a.epochs)
        run_experiment(model_name="mlp", owner="P2", model=mlp, df=df, split=split,
                       feature_set=fs, fit_n=a.fit_n,
                       params={"hidden": [512, 512], "dropout": 0.5, "optimizer": "SGD",
                               "learning_rate": 0.01, "batch_size": 200, "epochs": a.epochs},
                       paper_test_accuracy=PAPER_TEST_ACC[fs],
                       cv_info={"note": "no CV; 10% of TRAINING rows monitored per epoch"},
                       notes="architecture from poster + authors' code; lr is Keras default")
        hist = pd.DataFrame(mlp.history)
        hist.to_csv(RESULTS_DIR / "metrics" / f"mlp_{fs}_history.csv", index_label="epoch")
        fig, ax = plt.subplots(1, 2, figsize=(10, 4))
        hist[["loss", "val_loss"]].plot(ax=ax[0], title=f"MLP loss ({fs})")
        hist[["accuracy", "val_accuracy"]].plot(ax=ax[1], title=f"MLP accuracy ({fs})")
        for x in ax:
            x.set_xlabel("epoch")
        fig.tight_layout()
        fig.savefig(RESULTS_DIR / "figures" / f"mlp_{fs}_curves.png", dpi=150)


if __name__ == "__main__":
    main()
