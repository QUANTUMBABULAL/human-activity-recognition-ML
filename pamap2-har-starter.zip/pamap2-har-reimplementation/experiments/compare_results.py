"""Collect results/metrics/*.json into one comparison table + figure. OWNER: Person 2.

python -m experiments.compare_results
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from har.config import RESULTS_DIR

ORDER = ["logreg", "svm_rbf", "tree", "adaboost", "forest", "mlp"]


def main():
    rows = []
    for p in sorted((RESULTS_DIR / "metrics").glob("*.json")):
        r = json.loads(p.read_text())
        if r.get("protocol") != "random_85_15":
            continue                                  # extensions are reported separately
        rows.append({"model": r["model"], "feature_set": r["feature_set"],
                     "n_train": r["n_train"], "n_test": r["n_test"],
                     "our_train_acc": r["train_accuracy"], "our_test_acc": r["test_accuracy"],
                     "our_macro_f1": r["test_macro_f1"],
                     "paper_test_acc": r["paper_test_accuracy"],
                     "gap_pp": None if r["paper_test_accuracy"] is None else
                     100 * (r["test_accuracy"] - r["paper_test_accuracy"]),
                     "fit_s": r["fit_seconds"], "predict_s": r["predict_seconds"],
                     "params": json.dumps(r["params"])})
    df = pd.DataFrame(rows)
    df["model"] = pd.Categorical(df["model"], ORDER, ordered=True)
    df = df.sort_values(["model", "feature_set"])
    df.to_csv(RESULTS_DIR / "comparison_table.csv", index=False, float_format="%.4f")
    print(df.drop(columns="params").to_string(index=False, float_format="%.3f"))

    piv = df.pivot_table(index="model", columns="feature_set", values="our_test_acc",
                         observed=True)
    ax = piv.plot.bar(figsize=(8, 4), rot=0, ylim=(0, 1), title="Test accuracy (ours)")
    ax.set_ylabel("accuracy")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "figures" / "test_accuracy_full_vs_reduced.png", dpi=150)


if __name__ == "__main__":
    main()
