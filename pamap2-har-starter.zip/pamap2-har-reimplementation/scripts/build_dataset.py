"""Build data/processed/*.parquet + split file. OWNER: Person 1.

Run from the repo root:   python -m scripts.build_dataset
Optional:                  python -m scripts.build_dataset --hr-method ffill
"""
import argparse
import json

from har.config import PROCESSED_DIR, RAW_DIR, RESULTS_DIR
from har.data import PROCESSED_FILE, build_dataset
from har.splits import SPLIT_FILE, make_random_split, save_split, write_split_meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-dir", default=str(RAW_DIR))
    ap.add_argument("--hr-method", default="linear", choices=["linear", "ffill"])
    args = ap.parse_args()

    df, log = build_dataset(args.raw_dir, hr_method=args.hr_method)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    suffix = "" if args.hr_method == "linear" else f"_{args.hr_method}"
    df.to_parquet(PROCESSED_DIR / PROCESSED_FILE.replace(".parquet", f"{suffix}.parquet"),
                  index=False)

    split = make_random_split(len(df))
    save_split(split, PROCESSED_DIR / SPLIT_FILE.replace(".npz", f"{suffix}.npz"))
    meta = write_split_meta(split, len(df), RESULTS_DIR / f"split_meta{suffix}.json")
    (RESULTS_DIR / f"cleaning_log{suffix}.json").write_text(json.dumps(log, indent=2))
    print(f"rows={len(df):,}  train={meta['n_train']:,}  test={meta['n_test']:,}  "
          f"fingerprint={meta['fingerprint']}")


if __name__ == "__main__":
    main()
