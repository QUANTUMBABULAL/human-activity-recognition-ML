"""Day-1 raw-data audit. OWNER: Person 1.

python -m scripts.audit_raw            -> prints tables and writes docs/data_audit.md
Checks the assumptions the cleaning code relies on BEFORE trusting it.
"""
import argparse

import numpy as np
import pandas as pd

from har.config import ACTIVITY_NAMES, LABEL_ORDER, RAW_COLUMNS, RAW_DIR, REPO_ROOT


def audit_file(path):
    df = pd.read_csv(path, sep=r"\s+", header=None)
    out = {"file": path.name, "n_cols": df.shape[1], "rows": len(df),
           "size_MB": round(path.stat().st_size / 1e6, 1)}
    if df.shape[1] != 54:
        return out, None
    df.columns = RAW_COLUMNS
    t = df["timestamp"]
    out.update({
        "t_start_s": round(float(t.iloc[0]), 2), "t_end_s": round(float(t.iloc[-1]), 2),
        "t_sorted": bool(t.is_monotonic_increasing), "dup_timestamps": int(t.duplicated().sum()),
        "dup_rows": int(df.duplicated().sum()),
        "label0_frac": round(float((df["activity_id"] == 0).mean()), 3),
        "unexpected_labels": sorted(set(df["activity_id"].astype(int)) - set(LABEL_ORDER) - {0}),
        "hr_nan_frac": round(float(df["heart_rate"].isna().mean()), 3),
        "imu_nan_frac_max": round(float(df.iloc[:, 3:].isna().mean().max()), 4),
    })
    counts = df["activity_id"].astype(int).value_counts()
    return out, counts.rename(path.stem)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-dir", default=str(RAW_DIR))
    from pathlib import Path
    files = sorted(Path(ap.parse_args().raw_dir).glob("*.dat"))
    rows, counts = [], []
    for f in files:
        r, c = audit_file(f)
        rows.append(r)
        if c is not None:
            counts.append(c)
    summary = pd.DataFrame(rows)
    cc = pd.concat(counts, axis=1).fillna(0).astype(int).sort_index()
    cc.index = [f"{i} {ACTIVITY_NAMES.get(i, 'transient/other')}" for i in cc.index]
    cc["TOTAL"] = cc.sum(axis=1)
    print(summary.to_string(index=False)); print(); print(cc.to_string())
    non0 = int(cc.drop(index=[i for i in cc.index if i.startswith("0 ")])["TOTAL"].sum())
    md = ["# PAMAP2 raw-data audit", "", "## Files", "", summary.to_markdown(index=False), "",
          "## Rows per activity and subject (raw, before cleaning)", "", cc.to_markdown(), "",
          f"Rows with a protocol label (label 0 excluded): **{non0:,}**  "
          f"(report: about 1.9 million data points)", ""]
    (REPO_ROOT / "docs" / "data_audit.md").write_text("\n".join(md))
    print(f"\nrows with labels != 0: {non0:,}  -> docs/data_audit.md")


if __name__ == "__main__":
    main()
