"""End-to-end: fake raw files -> clean -> split -> logistic regression -> result JSON.
OWNER: Person 1."""
import json

from har.data import build_dataset
from har.metrics import REQUIRED_KEYS
from har.models_p1 import logreg
from har.runner import run_experiment
from har.splits import make_random_split
from har.synthetic import write_fake_dat_files


def test_end_to_end(tmp_path):
    write_fake_dat_files(tmp_path / "raw", subjects=(101, 102, 103), n_rows=1500)
    df, _ = build_dataset(tmp_path / "raw")
    split = make_random_split(len(df))
    rec = run_experiment(model_name="logreg", owner="P1", model=logreg.build(C=1.0, max_iter=200),
                         df=df, split=split, feature_set="reduced", params={"C": 1.0},
                         results_dir=tmp_path / "results")
    saved = json.loads((tmp_path / "results/metrics/logreg_reduced.json").read_text())
    assert REQUIRED_KEYS <= saved.keys()
    assert saved["n_train"] + saved["n_test"] == len(df) == rec["n_train"] + rec["n_test"]
    assert (tmp_path / "results/confusion/logreg_reduced.csv").exists()
