"""Loader / cleaning tests. OWNER: Person 1."""
import numpy as np
import pandas as pd
import pytest

from har.config import FEATURE_SETS, FORBIDDEN_FEATURES, LABEL_ORDER, RAW_COLUMNS
from har.data import build_dataset, clean_subject, fill_heart_rate, get_xy, load_subject
from har.synthetic import write_fake_dat_files


@pytest.fixture(scope="module")
def raw_dir(tmp_path_factory):
    d = tmp_path_factory.mktemp("raw")
    write_fake_dat_files(d, subjects=(101, 102), n_rows=2000)
    return d


def test_load_keeps_first_row_and_needed_columns(raw_dir):
    df = load_subject(raw_dir / "subject101.dat")
    assert len(df) == 2000                       # header=None: line 1 is data, not a header
    assert "hand_ori_0" not in df.columns        # unused columns never loaded
    assert set(FEATURE_SETS["full"]) <= set(df.columns)


def test_feature_sets_sizes_and_no_leakage():
    assert len(RAW_COLUMNS) == 54
    assert len(FEATURE_SETS["reduced"]) == 11 and len(FEATURE_SETS["full"]) == 31
    assert set(FEATURE_SETS["reduced"]) <= set(FEATURE_SETS["full"])
    for cols in FEATURE_SETS.values():
        assert not FORBIDDEN_FEATURES & set(cols)
        assert all(c == "heart_rate" or "ori" not in c and "acc6" not in c for c in cols)


def test_linear_interpolation_values_and_boundaries():
    df = pd.DataFrame({"timestamp": [0.0, 0.01, 0.02, 0.03, 0.04, 0.05],
                       "heart_rate": [np.nan, 100.0, np.nan, np.nan, 130.0, np.nan]})
    out = fill_heart_rate(df, "linear")["heart_rate"].to_numpy()
    assert np.isnan(out[0]) and np.isnan(out[5])            # no extrapolation at edges
    np.testing.assert_allclose(out[1:5], [100, 110, 120, 130])
    ff = fill_heart_rate(df, "ffill")["heart_rate"].to_numpy()
    np.testing.assert_allclose(ff[1:], [100, 100, 100, 130, 130])


def test_clean_subject_policy(raw_dir):
    clean, log = clean_subject(load_subject(raw_dir / "subject101.dat"), 101)
    assert set(clean["activity_id"].unique()) <= set(LABEL_ORDER)       # no label 0
    assert not clean[FEATURE_SETS["full"]].isna().any().any()
    assert log["rows_clean"] == len(clean) and log["rows_dropped_nan"] > 0


def test_build_dataset_and_get_xy(raw_dir):
    df, log = build_dataset(raw_dir)
    assert df["row_id"].tolist() == list(range(len(df)))
    assert sorted(df["subject_id"].unique()) == [101, 102]
    for fs in FEATURE_SETS:
        X, y = get_xy(df, fs)
        assert X.dtype == np.float32 and X.shape == (len(df), len(FEATURE_SETS[fs]))
        assert np.isfinite(X).all() and set(np.unique(y)) <= set(LABEL_ORDER)
    assert sum(log["class_counts"].values()) == len(df)


def test_interpolation_does_not_cross_subjects(raw_dir):
    df, _ = build_dataset(raw_dir)
    first = df[df["subject_id"] == 102].iloc[0]
    raw102 = load_subject(raw_dir / "subject102.dat")
    first_valid_t = raw102.loc[raw102["heart_rate"].notna(), "timestamp"].iloc[0]
    assert first["timestamp"] >= first_valid_t     # rows before subject 102's 1st HR dropped
