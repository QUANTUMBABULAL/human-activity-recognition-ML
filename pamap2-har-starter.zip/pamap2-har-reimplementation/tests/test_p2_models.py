"""P2 model output tests on synthetic data. OWNER: Person 2."""
import numpy as np
import pytest

from har.config import LABEL_ORDER
from har.data import get_xy
from har.models_p2 import trees
from har.models_p2.selection import one_sd_rule
from har.synthetic import fake_processed_df

DF = fake_processed_df(1500)


@pytest.mark.parametrize("fs", ["full", "reduced"])
@pytest.mark.parametrize("make", [lambda: trees.build_tree(10),
                                  lambda: trees.build_forest(10, n_estimators=20),
                                  lambda: trees.build_adaboost(3, n_estimators=10)])
def test_p2_model_output(make, fs):
    X, y = get_xy(DF, fs)
    pred = make().fit(X[:1200], y[:1200]).predict(X[1200:])
    assert pred.shape == (300,) and set(np.unique(pred)) <= set(LABEL_ORDER)
    assert (pred == y[1200:]).mean() > 1 / len(LABEL_ORDER)


def test_one_sd_rule_picks_simplest_within_one_sd():
    assert one_sd_rule([5, 10, 15, 20], [0.80, 0.90, 0.93, 0.94], [0.01, 0.01, 0.01, 0.02]) == 15


def test_mlp_two_epochs():
    pytest.importorskip("keras")
    from har.models_p2.mlp import KerasMLP
    X, y = get_xy(DF, "reduced")
    m = KerasMLP(epochs=2, verbose=0).fit(X[:1200], y[:1200])
    pred = m.predict(X[1200:])
    assert pred.shape == (300,) and set(np.unique(pred)) <= set(LABEL_ORDER)
    assert len(m.history["loss"]) == 2
