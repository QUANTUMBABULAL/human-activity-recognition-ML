"""P1 model output tests on synthetic data. OWNER: Person 1."""
import numpy as np
import pytest

from har.config import LABEL_ORDER
from har.data import get_xy
from har.models_p1 import logreg, svm
from har.synthetic import fake_processed_df

DF = fake_processed_df(1500)


@pytest.mark.parametrize("fs", ["full", "reduced"])
@pytest.mark.parametrize("make", [lambda: logreg.build(C=1.0, max_iter=300),
                                  lambda: svm.build("rbf", C=10.0)])
def test_p1_model_output(make, fs):
    X, y = get_xy(DF, fs)
    pred = make().fit(X[:1200], y[:1200]).predict(X[1200:])
    assert pred.shape == (300,) and set(np.unique(pred)) <= set(LABEL_ORDER)
    assert (pred == y[1200:]).mean() > 1 / len(LABEL_ORDER)      # better than chance
