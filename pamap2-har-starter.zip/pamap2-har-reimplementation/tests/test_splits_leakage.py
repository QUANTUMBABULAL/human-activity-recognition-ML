"""Split + leakage tests. OWNER: Person 1."""
import numpy as np

from har.models_p1 import logreg
from har.splits import make_random_split, split_fingerprint
from har.synthetic import fake_processed_df
from har.data import get_xy


def test_split_disjoint_complete_deterministic():
    s1, s2 = make_random_split(10_000), make_random_split(10_000)
    assert split_fingerprint(s1) == split_fingerprint(s2)
    assert len(np.intersect1d(s1["train"], s1["test"])) == 0
    assert len(s1["train"]) + len(s1["test"]) == 10_000
    assert len(s1["test"]) == 1500
    assert split_fingerprint(make_random_split(10_000, seed=1)) != split_fingerprint(s1)


def test_scaler_is_fit_on_training_rows_only():
    df = fake_processed_df(2000)
    s = make_random_split(len(df))
    X_tr, y_tr = get_xy(df, "full", s["train"])
    X_te, _ = get_xy(df, "full", s["test"])
    X_te = X_te + 1000.0                                   # poison test rows
    model = logreg.build(C=1.0, max_iter=200).fit(X_tr, y_tr)
    np.testing.assert_allclose(model.named_steps["scale"].mean_, X_tr.mean(axis=0), rtol=1e-4)
    model.predict(X_te)                                    # predicting must not refit
    np.testing.assert_allclose(model.named_steps["scale"].mean_, X_tr.mean(axis=0), rtol=1e-4)
