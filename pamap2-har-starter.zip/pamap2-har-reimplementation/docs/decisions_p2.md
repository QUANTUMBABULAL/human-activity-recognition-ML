# Decisions and deviations log — Person 2 (trees, AdaBoost, RF, MLP). OWNER: Person 2. Append-only.

Format: `D-NN | date | owner | decision | paper says | why | effect on comparability`

| ID | Owner | Decision | Paper / poster / code says | Why |
|---|---|---|---|---|
| D-09 | P2 | AdaBoost uses SAMME (only option in scikit-learn ≥1.6) | 2018 scikit-learn default was SAMME.R | Library change |
| D-10 | P2 | MLP output = 12 units (activity IDs mapped to 0..11) | Report: k = 18; authors' code: k = max ID + 1 = 25 | Unused output units removed |
| D-11 | P2 | MLP learning rate 0.01 (Keras SGD default) | Not stated | Not stated in paper |
