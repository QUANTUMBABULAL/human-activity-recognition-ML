# Decisions and deviations log — Person 1 (data, LR, SVM). OWNER: Person 1. Append-only.

Format: `D-NN | date | owner | decision | paper says | why | effect on comparability`

| ID | Owner | Decision | Paper / poster / code says | Why |
|---|---|---|---|---|
| D-01 | P1 | Use the 9 files in `Protocol/` only; drop activity 0 | Report: 12 activities, 9 subjects; poster: "18 activity IDs" (whole dataset) | 12 protocol labels match the report |
| D-02 | P1 | Heart rate: time-linear interpolation per subject, before dropping label 0; no extrapolation at file edges | Report: linear interpolation. Authors' code: forward-fill after dropping label 0 | Report is the primary reference; `--hr-method ffill` available |
| D-03 | P1 | Drop rows with any NaN in the 31 full-set columns (both sets use identical rows) | Authors' code drops rows with any NaN | Same rows => comparable full vs reduced |
| D-04 | P1 | Features: 10 per IMU (temp, ±16 g acc, gyro, mag) + HR; full=31, reduced=11 | Report Fig. 1 caption: n ranges 12–52; authors' code: 10/IMU + HR | Code is the only exact column list; ±6 g acc and orientation excluded |
| D-05 | P1 | Random row-level 85/15 split, seed 229, saved indices | Report: random 85/15 | Faithful; seed added for reproducibility |
| D-06 | both | Scaler inside a Pipeline (fit on training folds only) | Report: training mean/std | Prevents fold leakage |
| D-07 | P1 | LR: tune C on 200k-row training subsample, final fit on all training rows | Report: 5-fold CV over C | Time budget |
| D-08 | P1 | SVM: tune on 20k rows, final fit on 50k rows | Authors' code capped SVM at 175k rows | Kernel SVM cost grows ~quadratically |
