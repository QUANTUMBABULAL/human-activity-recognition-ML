"""Figures from saved result files. OWNER: Person 1 (kickoff, then frozen). Used by both.

python -m har.plots --cm adaboost_reduced tree_full --curve tree_reduced:max_depth logreg_full:C:log
"""
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from har.config import ACTIVITY_NAMES, LABEL_ORDER, RESULTS_DIR


def plot_confusion(stem):
    """Row-normalised confusion matrix: each row shows how one TRUE activity was predicted."""
    cm = pd.read_csv(RESULTS_DIR / "confusion" / f"{stem}.csv", index_col=0).to_numpy()
    cmn = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    names = [ACTIVITY_NAMES[i] for i in LABEL_ORDER]
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(12), names, rotation=60, ha="right")
    ax.set_yticks(range(12), names)
    for i in range(12):
        for j in range(12):
            if cm[i, j]:
                ax.text(j, i, f"{cmn[i, j]:.2f}", ha="center", va="center", fontsize=6,
                        color="white" if cmn[i, j] > 0.5 else "black")
    ax.set_xlabel("predicted activity"); ax.set_ylabel("true activity"); ax.set_title(stem)
    fig.colorbar(im, fraction=0.046); fig.tight_layout()
    fig.savefig(RESULTS_DIR / "figures" / f"{stem}_cm.png", dpi=150); plt.close(fig)


def plot_valcurve(stem, param, log_x=False):
    """Training vs 5-fold validation accuracy from a *_cv.csv table."""
    t = pd.read_csv(RESULTS_DIR / "metrics" / f"{stem}_cv.csv")
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(t[param], t["train_mean"], "o-", label="training (CV folds)")
    ax.errorbar(t[param], t["val_mean"], yerr=t["val_std"], fmt="s-", capsize=3,
                label="5-fold validation")
    if log_x:
        ax.set_xscale("log")
    ax.set_xlabel(param); ax.set_ylabel("accuracy"); ax.set_title(stem); ax.legend()
    fig.tight_layout(); fig.savefig(RESULTS_DIR / "figures" / f"{stem}_valcurve.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--cm", nargs="*", default=[], help="result stems, e.g. tree_reduced")
    ap.add_argument("--curve", nargs="*", default=[], help="stem:param[:log], e.g. logreg_full:C:log")
    a = ap.parse_args()
    for stem in a.cm:
        plot_confusion(stem)
    for spec in a.curve:
        stem, param, *log = spec.split(":")
        plot_valcurve(stem, param, log_x=bool(log))
