"""Multilayer perceptron (Keras). OWNER: Person 2.

Paper + authors' code: Dense(512, ReLU) -> Dropout(0.5) -> Dense(512, ReLU) -> Dropout(0.5)
-> Dense(k, softmax); categorical cross-entropy; SGD optimiser; batch 200 in the code;
100 epochs shown in the report's training-curve figure. Learning rate is NOT stated:
we use Keras' SGD default (0.01) and record it.
"""
from __future__ import annotations

import numpy as np
from sklearn.preprocessing import StandardScaler

from har.config import LABEL_ORDER, SEED

PAPER_TEST_ACC = {"full": 0.981, "reduced": 0.814}


class KerasMLP:
    """sklearn-style wrapper: .fit(X, y) / .predict(X) with original activity IDs."""

    def __init__(self, hidden=(512, 512), dropout=0.5, epochs=100, batch_size=200,
                 learning_rate=0.01, val_fraction=0.1, verbose=2):
        self.hidden, self.dropout = hidden, dropout
        self.epochs, self.batch_size, self.lr = epochs, batch_size, learning_rate
        self.val_fraction, self.verbose = val_fraction, verbose
        self.labels = np.array(LABEL_ORDER)            # index i <-> activity ID labels[i]

    def _build(self, n_features):
        import keras
        keras.utils.set_random_seed(SEED)
        layers = [keras.Input(shape=(n_features,))]
        for h in self.hidden:
            layers += [keras.layers.Dense(h, activation="relu"),
                       keras.layers.Dropout(self.dropout)]
        layers.append(keras.layers.Dense(len(self.labels), activation="softmax"))
        model = keras.Sequential(layers)
        model.compile(optimizer=keras.optimizers.SGD(learning_rate=self.lr),
                      loss="sparse_categorical_crossentropy",   # = categorical CE on one-hot
                      metrics=["accuracy"])
        return model

    def fit(self, X, y):
        self.scaler = StandardScaler().fit(X)                   # training rows only
        Xs = self.scaler.transform(X).astype(np.float32)
        yi = np.searchsorted(self.labels, y)                    # IDs -> 0..11
        assert np.array_equal(self.labels[yi], y), "unexpected label"
        # Keras' validation_split takes the LAST rows; our rows are ordered by subject,
        # so shuffle first or the "validation" curve would be one or two subjects only.
        perm = np.random.default_rng(SEED).permutation(len(yi))
        Xs, yi = Xs[perm], yi[perm]
        self.model = self._build(X.shape[1])
        self.history = self.model.fit(Xs, yi, epochs=self.epochs, batch_size=self.batch_size,
                                      validation_split=self.val_fraction,
                                      verbose=self.verbose).history
        return self

    def predict(self, X):
        p = self.model.predict(self.scaler.transform(X).astype(np.float32),
                               batch_size=4096, verbose=0)
        return self.labels[p.argmax(axis=1)]
