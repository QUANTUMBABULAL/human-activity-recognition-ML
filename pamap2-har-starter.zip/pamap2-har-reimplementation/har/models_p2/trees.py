"""Decision tree, AdaBoost and random forest builders. OWNER: Person 2.

Paper settings:
  Decision tree : Gini, regularised by max_depth; depth 15 chosen (one-SD rule), both sets.
  AdaBoost      : default learning rate; weak learner depth 1-10 x {50,100,250,500} trees;
                  chosen 500 trees/depth 10 (reduced) and 250 trees/depth 9 (full).
  Random forest : 100 trees, sqrt(n_features) per split; depth 20 chosen, both sets.
No scaling: tree splits are thresholds, so feature scale does not matter.
"""
import numpy as np
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.model_selection import KFold, validation_curve
from sklearn.tree import DecisionTreeClassifier

from har.config import N_FOLDS, SEED
from har.models_p2.selection import one_sd_rule

PAPER = {
    "tree": {"full": {"max_depth": 15}, "reduced": {"max_depth": 15}},
    "adaboost": {"full": {"max_depth": 9, "n_estimators": 250},
                 "reduced": {"max_depth": 10, "n_estimators": 500}},
    "forest": {"full": {"max_depth": 20, "n_estimators": 100},
               "reduced": {"max_depth": 20, "n_estimators": 100}},
}
PAPER_TEST_ACC = {"tree": {"full": 0.927, "reduced": 0.873},
                  "adaboost": {"full": 0.985, "reduced": 0.940},
                  "forest": {"full": 0.980, "reduced": 0.937}}
TREE_DEPTHS = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50]
FOREST_DEPTHS = [5, 10, 15, 20, 25, 30, 40, 50, 60]


def build_tree(max_depth=15):
    return DecisionTreeClassifier(criterion="gini", max_depth=max_depth, random_state=SEED)


def build_adaboost(max_depth=10, n_estimators=500):
    # Modern scikit-learn only implements the SAMME algorithm (2018 default was SAMME.R).
    return AdaBoostClassifier(estimator=DecisionTreeClassifier(max_depth=max_depth),
                              n_estimators=n_estimators, learning_rate=1.0, random_state=SEED)


def build_forest(max_depth=20, n_estimators=100, n_jobs=-1):
    return RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth,
                                  max_features="sqrt", n_jobs=n_jobs, random_state=SEED)


def depth_curve(estimator, X, y, depths, n_jobs=-1):
    """5-fold validation curve over max_depth on TRAINING rows; one-SD-rule choice."""
    cv = KFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    tr, va = validation_curve(estimator, X, y, param_name="max_depth", param_range=depths,
                              cv=cv, scoring="accuracy", n_jobs=n_jobs)
    table = [{"max_depth": d, "train_mean": float(t.mean()), "val_mean": float(v.mean()),
              "val_std": float(v.std())} for d, t, v in zip(depths, tr, va)]
    chosen = one_sd_rule(depths, va.mean(axis=1), va.std(axis=1))
    return chosen, table


def adaboost_grid(X, y, depths=range(1, 11), n_estimators=(50, 100, 250, 500), n_jobs=-1):
    """Depth x n_estimators table (5-fold CV). Expensive: run on a subsample."""
    cv = KFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    rows = []
    for d in depths:
        tr, va = validation_curve(build_adaboost(d, 50), X, y, param_name="n_estimators",
                                  param_range=list(n_estimators), cv=cv,
                                  scoring="accuracy", n_jobs=n_jobs)
        for n, t, v in zip(n_estimators, tr, va):
            rows.append({"max_depth": d, "n_estimators": n, "train_mean": float(t.mean()),
                         "val_mean": float(v.mean()), "val_std": float(v.std())})
    # simplicity order: fewer trees, then shallower
    rows_sorted = sorted(rows, key=lambda r: (r["max_depth"] * r["n_estimators"]))
    best = max(rows, key=lambda r: r["val_mean"])
    chosen = next(r for r in rows_sorted if r["val_mean"] >= best["val_mean"] - best["val_std"])
    return chosen, rows
