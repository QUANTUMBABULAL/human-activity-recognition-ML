"""Model-selection helper for tree models. OWNER: Person 2."""
import numpy as np


def one_sd_rule(values, val_mean, val_std):
    """Report: pick the SIMPLEST setting whose mean CV accuracy is within one standard
    deviation of the best setting's mean. `values` must be sorted simplest -> most complex.
    (Textbooks use the standard ERROR, std/sqrt(k); the report says standard deviation.
    We follow the report and log both in the CV table.)"""
    val_mean, val_std = np.asarray(val_mean), np.asarray(val_std)
    b = int(np.argmax(val_mean))
    threshold = val_mean[b] - val_std[b]
    for v, m in zip(values, val_mean):
        if m >= threshold:
            return v
    return values[b]
