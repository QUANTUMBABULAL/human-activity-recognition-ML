"""Synthetic PAMAP2-shaped data. OWNER: Person 1 (kickoff, then frozen).

Lets Person 2 build and test models on Day 1 without the real dataset or finished
preprocessing. Values are FAKE - never report numbers computed on them.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from har.config import FEATURE_SETS, LABEL_ORDER, RAW_COLUMNS


def fake_processed_df(n_rows: int = 3000, n_subjects: int = 3, seed: int = 0) -> pd.DataFrame:
    """A DataFrame in the SAME format as har.data.load_processed()."""
    rng = np.random.default_rng(seed)
    y = rng.choice(LABEL_ORDER, size=n_rows)
    df = pd.DataFrame({"row_id": np.arange(n_rows),
                       "subject_id": np.repeat(np.arange(101, 101 + n_subjects),
                                               int(np.ceil(n_rows / n_subjects)))[:n_rows],
                       "timestamp": np.arange(n_rows) * 0.01,
                       "activity_id": y.astype(np.int16)})
    centers = rng.normal(0, 3, size=(max(LABEL_ORDER) + 1, len(FEATURE_SETS["full"])))
    X = centers[y] + rng.normal(0, 1, size=(n_rows, len(FEATURE_SETS["full"])))
    for j, c in enumerate(FEATURE_SETS["full"]):
        df[c] = X[:, j].astype(np.float32)
    return df


def write_fake_dat_files(out_dir: str | Path, subjects=(101, 102), n_rows: int = 2000,
                         seed: int = 0) -> list[Path]:
    """Write raw .dat files with PAMAP2 quirks: label-0 segments, ~9 Hz heart rate,
    sporadic IMU dropouts (NaN). Used by Person 1's loader tests."""
    rng = np.random.default_rng(seed)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for s in subjects:
        a = rng.normal(size=(n_rows, len(RAW_COLUMNS)))
        a[:, 0] = np.arange(n_rows) * 0.01 + 5.0                      # timestamp (s)
        seg = np.repeat(rng.choice([0] + LABEL_ORDER, size=n_rows // 100 + 1), 100)[:n_rows]
        seg[:150] = 0                                                  # starts in transient
        a[:, 1] = seg
        hr = np.full(n_rows, np.nan)
        hr[20::11] = rng.uniform(70, 160, size=len(hr[20::11]))        # ~9 Hz, first rows NaN
        a[:, 2] = hr
        drop = rng.random(n_rows) < 0.01
        a[drop, 4:7] = np.nan                                          # hand acc dropouts
        p = out_dir / f"subject{s}.dat"
        np.savetxt(p, a, fmt="%.6g", delimiter=" ")
        paths.append(p)
    return paths
